/* CaptionKit by Motionsfly — host script for After Effects + Premiere Pro.
   Every public function takes one URI-encoded JSON argument and returns a JSON string. */

/* ---------------- tiny JSON for ExtendScript ---------------- */
var CK = CK || {};
CK.str = function (v) {
    var t = typeof v;
    if (v === null || v === undefined) return 'null';
    if (t === 'number') return isFinite(v) ? String(v) : 'null';
    if (t === 'boolean') return v ? 'true' : 'false';
    if (t === 'string') {
        return '"' + v.replace(/[\\"\u0000-\u001f]/g, function (c) {
            var m = { '"': '\\"', '\\': '\\\\', '\n': '\\n', '\r': '\\r', '\t': '\\t' };
            return m[c] || ('\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4));
        }) + '"';
    }
    if (v instanceof Array) {
        var a = [];
        for (var i = 0; i < v.length; i++) a.push(CK.str(v[i]));
        return '[' + a.join(',') + ']';
    }
    var o = [];
    for (var k in v) if (v.hasOwnProperty(k) && typeof v[k] !== 'function') o.push(CK.str(k) + ':' + CK.str(v[k]));
    return '{' + o.join(',') + '}';
};
CK.parse = function (s) { return eval('(' + decodeURIComponent(s) + ')'); };
CK.ok = function (o) { o = o || {}; o.ok = true; return CK.str(o); };
CK.fail = function (e) { return CK.str({ ok: false, error: String(e && e.message ? e.message : e) + (e && e.line ? ' (line ' + e.line + ')' : '') }); };
CK.isAE = function () { return BridgeTalk.appName === 'aftereffects'; };
CK.hex = function (h) {
    h = String(h || '#ffffff').replace('#', '');
    if (h.length === 3) h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
    var n = parseInt(h, 16);
    return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
};
CK.arr = function (a, dp) {
    var o = [];
    for (var i = 0; i < a.length; i++) o.push(typeof a[i] === 'number' ? (Math.round(a[i] * Math.pow(10, dp || 3)) / Math.pow(10, dp || 3)) : a[i]);
    return '[' + o.join(',') + ']';
};

/* ---------------- shared ---------------- */
function ck_env(arg) {
    try {
        var r = { app: CK.isAE() ? 'AEFT' : 'PPRO', version: app.version, os: $.os };
        if (CK.isAE()) {
            var c = app.project.activeItem;
            if (c && c instanceof CompItem) r.target = { name: c.name, w: c.width, h: c.height, fps: c.frameRate, dur: c.duration };
        } else {
            var s = app.project.activeSequence;
            if (s) {
                var fps = 254016000000 / parseFloat(s.timebase);
                r.target = { name: s.name, w: s.frameSizeHorizontal, h: s.frameSizeVertical, fps: fps, dur: parseFloat(s.end) / 254016000000 };
            }
            r.projectPath = app.project.path || '';
        }
        return CK.ok(r);
    } catch (e) { return CK.fail(e); }
}

function ck_sources(arg) {
    try {
        var a = CK.parse(arg);
        return CK.isAE() ? CK.aeSources(a.mode) : CK.ppSources(a.mode);
    } catch (e) { return CK.fail(e); }
}

/* =====================================================================
   AFTER EFFECTS
   ===================================================================== */
CK.aeSources = function (mode) {
    var comp = app.project.activeItem;
    if (!(comp && comp instanceof CompItem)) throw new Error('Open a composition first.');
    var segs = [], notes = [];
    function collect(c, layers, off, k, lo, hi, depth) {
        for (var i = 0; i < layers.length; i++) {
            var L = layers[i];
            if (!(L instanceof AVLayer)) continue;
            var src = L.source, st = L.stretch / 100;
            if (st <= 0) { notes.push(L.name + ': reversed layers are skipped'); continue; }
            if (L.timeRemapEnabled) notes.push(L.name + ': time-remap ignored');
            var inT = Math.max(L.inPoint, 0), outT = Math.min(L.outPoint, c.duration);
            // outer-time window of this layer
            var oIn = Math.max(off + inT * k, lo), oOut = Math.min(off + outT * k, hi);
            if (oOut - oIn < 0.05) continue;
            if (src instanceof CompItem) {
                if (depth < 3 && (mode === 'selected' || (L.hasAudio && L.audioEnabled))) {
                    var all = [];
                    for (var j = 1; j <= src.numLayers; j++) all.push(src.layer(j));
                    collect(src, all, off + L.startTime * k, k * st, oIn, oOut, depth + 1);
                }
                continue;
            }
            if (!(src instanceof FootageItem) || !src.file) continue;
            if (!L.hasAudio) { if (mode === 'selected') notes.push(L.name + ': no audio'); continue; }
            if (mode !== 'selected' && !L.audioEnabled) continue;
            var kk = k * st, base = off + L.startTime * k;
            segs.push({
                path: src.file.fsName, name: L.name,
                tlStart: oIn, tlEnd: oOut,
                srcIn: (oIn - base) / kk, srcOut: (oOut - base) / kk, speed: 1 / kk
            });
        }
    }
    var layers = [];
    if (mode === 'selected') layers = comp.selectedLayers;
    else for (var i = 1; i <= comp.numLayers; i++) layers.push(comp.layer(i));
    if (mode === 'selected' && !layers.length) throw new Error('Select one or more layers with audio in the timeline.');
    collect(comp, layers, 0, 1, 0, comp.duration, 0);
    if (!segs.length) throw new Error('No layers with audio found' + (notes.length ? ' (' + notes.join('; ') + ')' : '.'));
    return CK.ok({ segments: segs, notes: notes, target: { w: comp.width, h: comp.height, fps: comp.frameRate } });
};

function ck_aeFonts(arg) {
    try {
        if (!app.fonts || !app.fonts.allFonts) return CK.ok({ fonts: [] });
        var out = [], fam = app.fonts.allFonts;
        for (var i = 0; i < fam.length && out.length < 4000; i++) {
            var g = fam[i];
            for (var j = 0; j < g.length; j++) out.push([g[j].familyName, g[j].styleName, g[j].postScriptName]);
        }
        return CK.ok({ fonts: out });
    } catch (e) { return CK.ok({ fonts: [] }); }
}

CK.easeExpr = function (name) {
    switch (name) {
        case 'linear': return 'p';
        case 'back': return '1+2.70158*Math.pow(p-1,3)+1.70158*Math.pow(p-1,2)';
        case 'bounce': return '(function(p){var n=7.5625,d=2.75;if(p<1/d)return n*p*p;if(p<2/d){p-=1.5/d;return n*p*p+.75;}if(p<2.5/d){p-=2.25/d;return n*p*p+.9375;}p-=2.625/d;return n*p*p+.984375;})(p)';
        case 'elastic': return '((p==0||p==1)?p:Math.pow(2,-10*p)*Math.sin((p*10-0.75)*(2*Math.PI/3))+1)';
        default: return '1-Math.pow(1-p,3)';
    }
};

CK.setByName = function (group, matchNames, names, value) {
    var i, p;
    for (i = 0; i < matchNames.length; i++) {
        try { p = group.property(matchNames[i]); if (p) { p.setValue(value); return true; } } catch (e) {}
    }
    try {
        for (i = 1; i <= group.numProperties; i++) {
            p = group.property(i);
            for (var n = 0; n < names.length; n++) if (p.name === names[n]) { p.setValue(value); return true; }
        }
    } catch (e2) {}
    return false;
};

/* Adds a text animator with an Expression Selector; props = [[matchName, value], ...] */
CK.addAnimator = function (layer, name, props, expr, basedOn) {
    var anims = layer.property('ADBE Text Properties').property('ADBE Text Animators');
    var an = anims.addProperty('ADBE Text Animator');
    an.name = name;
    var ap = an.property('ADBE Text Animator Properties');
    for (var i = 0; i < props.length; i++) {
        try { var p = ap.addProperty(props[i][0]); p.setValue(props[i][1]); } catch (e) {}
    }
    var sel = an.property('ADBE Text Selectors').addProperty('ADBE Text Expressible Selector');
    CK.setByName(sel, ['ADBE Text Range Type2', 'ADBE Text Expressible Based On'], ['Based On'], basedOn);
    var amt = sel.property('ADBE Text Expressible Amount');
    amt.expression = expr;
    return an;
};

CK.addShadowFx = function (layer, color, alpha, dist, dirDeg, soft) {
    var fx = layer.property('ADBE Effect Parade').addProperty('ADBE Drop Shadow');
    try { fx.property(1).setValue(CK.hex(color)); } catch (e) {}
    try { fx.property(2).setValue(alpha * 255); } catch (e1) { try { fx.property(2).setValue(alpha * 100); } catch (e1b) {} }
    try { fx.property(3).setValue(dirDeg); } catch (e2) {}
    try { fx.property(4).setValue(dist); } catch (e3) {}
    try { fx.property(5).setValue(soft); } catch (e4) {}
    return fx;
};

/* Builds one text layer for one caption part (a whole caption, or one line of a stacked style) */
CK.aeMakePart = function (comp, c, part, st, name, missing) {
    var size = part.size;
    var L = comp.layers.addText(part.text);
    L.name = name;
    L.comment = 'CaptionKit';
    try { L.label = 9; } catch (eL) {}
    var dp = L.property('ADBE Text Properties').property('ADBE Text Document');
    var td = dp.value;
    try { td.resetCharStyle(); td.resetParagraphStyle(); } catch (eR) {}
    td.text = part.text;
    td.font = part.fontPS;
    td.fontSize = size;
    td.applyFill = true;
    td.fillColor = CK.hex(part.fill || st.fill);
    var hasStroke = !!(st.stroke && st.stroke.w > 0) && !part.noStroke;
    var needStroke = hasStroke || !!st.wordBox;
    td.applyStroke = needStroke;
    if (needStroke) {
        td.strokeColor = CK.hex(hasStroke ? st.stroke.c : (part.fill || st.fill));
        td.strokeWidth = hasStroke ? Math.max(0.1, st.stroke.w * size) : 0.1;
        td.strokeOverFill = false;
    }
    try { td.lineJoinType = LineJoinType.LINE_JOIN_ROUND; } catch (eJ) {}
    td.justification = ParagraphJustification.CENTER_JUSTIFY;
    try { td.autoLeading = false; td.leading = size * 1.18; } catch (eLd) {}
    td.tracking = 0;
    if (part.kwFontPS && part.kwRanges && part.kwRanges.length) {
        try { for (var kr = 0; kr < part.kwRanges.length; kr++) td.characterRange(part.kwRanges[kr][0], part.kwRanges[kr][1]).font = part.kwFontPS; } catch (eK) {}
    }
    dp.setValue(td);
    try { if (dp.value.font !== part.fontPS) missing[part.fontPS] = 1; } catch (eF) {}

    L.inPoint = c.s; L.outPoint = c.e;

    var more = L.property('ADBE Text Properties').property('ADBE Text More Options');
    CK.setByName(more, ['ADBE Text Anchor Point Option'], ['Anchor Point Grouping'], st.unit === 'char' ? 1 : 2);
    CK.setByName(more, ['ADBE Text Anchor Point Align'], ['Grouping Alignment'], [0, -50]);
    if (needStroke) CK.setByName(more, ['ADBE Text Render Order'], ['Fill & Stroke'], 2);

    var W = CK.arr(part.W), E = CK.arr(part.E), WB = 3, idxW = 'var i=Math.min(textIndex-1,' + (part.W.length - 1) + ');';
    var r = 'var r=0.06;var t=time-inPoint;';

    var en = st.enter;
    if (en && st.unit !== 'none') {
        var T = st.unit === 'char' ? part.C : (st.unit === 'line' ? [0] : part.W);
        var based = st.unit === 'char' ? 2 : WB;
        var props = [];
        if (en.o !== undefined && en.o !== null) props.push(['ADBE Text Opacity', en.o * 100]);
        if (en.x || en.y) props.push(['ADBE Text Position 3D', [(en.x || 0) * size, (en.y || 0) * size, 0]]);
        if (en.s !== undefined && en.s !== null) props.push(['ADBE Text Scale 3D', [en.s * 100, (en.sy !== undefined ? en.sy * en.s : en.s) * 100, 100]]);
        else if (en.sy !== undefined && en.sy !== null) props.push(['ADBE Text Scale 3D', [100, en.sy * 100, 100]]);
        if (en.r) props.push(['ADBE Text Rotation', en.r]);
        if (en.blur) props.push(['ADBE Text Blur', [en.blur * size, en.blur * size]]);
        var head = 'var T=' + CK.arr(T) + ';var i=Math.min(textIndex-1,T.length-1);var dt=time-inPoint-T[i];';
        var body = en.ease === 'step' ? 'dt>0?0:100' :
            'var p=Math.min(Math.max(dt/' + Math.max(0.001, en.d || 0.3) + ',0),1);var e=' + CK.easeExpr(en.ease) + ';100*(1-e)';
        CK.addAnimator(L, 'CK Enter', props, head + body, based);
    }
    if (st.scramble && st.unit === 'char') {
        CK.addAnimator(L, 'CK Shuffle', [['ADBE Text Character Offset', 30]],
            'var T=' + CK.arr(part.C) + ';var i=Math.min(textIndex-1,T.length-1);var dt=time-inPoint-T[i];seedRandom(textIndex*7+timeToFrames(time),true);(dt>=0&&dt<' + st.scramble + ')?random(10,100):0', 2);
    }
    if (st.keyword && part.K) {
        var kp = [];
        if (st.keyword.c) kp.push(['ADBE Text Fill Color', CK.hex(st.keyword.c)]);
        if (st.keyword.s && st.keyword.s !== 1) kp.push(['ADBE Text Scale 3D', [st.keyword.s * 100, st.keyword.s * 100, 100]]);
        CK.addAnimator(L, 'CK Keyword', kp, 'var K=' + CK.arr(part.K) + ';K[Math.min(textIndex-1,K.length-1)]?100:0', WB);
    }
    if (st.spoken) {
        CK.addAnimator(L, 'CK Spoken', [['ADBE Text Fill Color', CK.hex(st.spoken.c)]],
            'var W=' + W + ';' + idxW + r + '100*Math.min(Math.max((t-W[i])/r,0),1)', WB);
    }
    if (st.upcoming) {
        CK.addAnimator(L, 'CK Upcoming', [['ADBE Text Opacity', st.upcoming.o * 100]],
            'var W=' + W + ';' + idxW + r + '100*(1-Math.min(Math.max((t-W[i])/r,0),1))', WB);
    }
    if (st.active || st.wordBox) {
        var ap = [];
        if (st.active && st.active.c) ap.push(['ADBE Text Fill Color', CK.hex(st.active.c)]);
        if (st.active && st.active.s && st.active.s !== 1) ap.push(['ADBE Text Scale 3D', [st.active.s * 100, st.active.s * 100, 100]]);
        if (st.active && st.active.y) ap.push(['ADBE Text Position 3D', [0, st.active.y * size, 0]]);
        if (st.wordBox) {
            ap.push(['ADBE Text Stroke Color', CK.hex(st.wordBox.c)]);
            ap.push(['ADBE Text Stroke Width', (st.wordBox.pad * 2 + 0.22) * size]);
        }
        CK.addAnimator(L, 'CK Active', ap,
            'var W=' + W + ';var E=' + E + ';' + idxW + r + '100*Math.min(Math.max(Math.min((t-W[i])/r,(E[i]-t)/r),0),1)', WB);
    }

    var tr = L.property('ADBE Transform Group');
    CK.aeLayerFx(L, st, size);

    var settle = Math.min(c.e - c.s - 0.02, (part.W.length ? part.W[part.W.length - 1] : 0) + (en ? (en.d || 0.3) : 0) + 0.05);
    var rect = null;
    try {
        rect = L.sourceRectAtTime(c.s + Math.max(0, settle), false);
        tr.property('ADBE Anchor Point').setValue([rect.left + rect.width / 2, rect.top + rect.height / 2]);
    } catch (eA) {}
    if (!rect) rect = { left: 0, top: -size, width: size * 4, height: size };
    return { layer: L, rect: rect, settle: settle };
};

/* exit / pulse expressions + glow + shadow for a caption layer (text or emoji) */
CK.aeLayerFx = function (L, st, size, noEffects) {
    var tr = L.property('ADBE Transform Group');
    if (st.exit) {
        var d = st.exit.d || 0.2, q = 'var d=' + d + ';var q=Math.min(Math.max((time-(outPoint-d))/d,0),1);';
        if (st.exit.o !== undefined) tr.property('ADBE Opacity').expression = q + 'value*(1+(' + st.exit.o + '-1)*q)';
        if (st.exit.y) tr.property('ADBE Position').expression = q + 'value+[0,q*' + (st.exit.y * size) + ']';
    }
    var sExpr = '';
    if (st.exit && st.exit.s !== undefined) sExpr += 'var d2=' + (st.exit.d || 0.2) + ';var q2=Math.min(Math.max((time-(outPoint-d2))/d2,0),1);m*=1+(' + st.exit.s + '-1)*q2;';
    if (st.loop && st.loop.pulse) sExpr += 'm*=1+' + st.loop.pulse + '*Math.sin(2*Math.PI*' + (st.loop.f || 2) + '*(time-inPoint));';
    if (sExpr) tr.property('ADBE Scale').expression = 'var m=1;' + sExpr + 'value*m';
    if (noEffects) return;
    if (st.glow) {
        CK.addShadowFx(L, st.glow.c, st.glow.a, 0, 0, st.glow.blur * size);
        CK.addShadowFx(L, st.glow.c, st.glow.a * 0.8, 0, 0, st.glow.blur * size * 0.45);
    }
    if (st.shadow) {
        var dx = (st.shadow.dx || 0), dy = (st.shadow.dy || 0);
        var dir = Math.atan2(dx, -dy) * 180 / Math.PI; if (dir < 0) dir += 360;
        CK.addShadowFx(L, st.shadow.c, st.shadow.a, Math.sqrt(dx * dx + dy * dy) * size, dir, (st.shadow.blur || 0) * size);
    }
};

/* 3D emoji PNG as an image layer above the caption */
CK.aeEmojiItem = function (path) {
    var f = new File(path);
    if (!f.exists) return null;
    var fs = f.fsName;
    for (var i = 1; i <= app.project.numItems; i++) {
        var it = app.project.item(i);
        try { if (it instanceof FootageItem && it.file && it.file.fsName === fs) return it; } catch (e) {}
    }
    var item = app.project.importFile(new ImportOptions(f));
    try {
        var folder = null;
        for (var j = 1; j <= app.project.numItems; j++) { var x = app.project.item(j); if (x instanceof FolderItem && x.name === 'CaptionKit Emoji') { folder = x; break; } }
        if (!folder) folder = app.project.items.addFolder('CaptionKit Emoji');
        item.parentFolder = folder;
    } catch (e2) {}
    return item;
};

function ck_aeBuild(arg) {
    var missing = {};
    try {
        var a = CK.parse(arg);
        var comp = app.project.activeItem;
        if (!(comp && comp instanceof CompItem)) throw new Error('Open a composition first.');
        var st = a.style, made = 0;
        var cx = comp.width / 2, cy = comp.height * a.posY;
        app.beginUndoGroup('CaptionKit: Create Captions');
        if (a.replace) CK.aeClear(comp);

        for (var ci = 0; ci < a.captions.length; ci++) {
            var c = a.captions[ci];
            if (c.e <= c.s) continue;
            var base = 'CK ' + ('000' + (ci + 1)).slice(-3) + ' · ';
            var built = [];
            for (var pi = 0; pi < c.parts.length; pi++) {
                var part = c.parts[pi];
                built.push(CK.aeMakePart(comp, c, part, st, base + part.text.replace(/\r/g, ' ').substr(0, 26), missing));
            }
            // stack the parts vertically around cy (single part = centred on cy)
            var gap = c.parts.length > 1 ? st.sizePx * 0.06 : 0, H = 0, k;
            for (k = 0; k < built.length; k++) H += built[k].rect.height + (k ? gap : 0);
            var y = cy - H / 2, top = 1e9;
            for (k = 0; k < built.length; k++) {
                var bh = built[k].rect.height, py = y + bh / 2;
                built[k].layer.property('ADBE Transform Group').property('ADBE Position').setValue([cx, py]);
                top = Math.min(top, py - bh / 2);
                y += bh + gap;
            }
            // caption box (single-part styles)
            if (st.box && built.length === 1) {
                try {
                    var L0 = built[0].layer, rb = built[0].rect, pad = st.box.pad * st.sizePx;
                    var B = comp.layers.addShape();
                    B.name = L0.name + ' Box'; B.comment = 'CaptionKit';
                    B.inPoint = c.s; B.outPoint = c.e;
                    var grp = B.property('ADBE Root Vectors Group').addProperty('ADBE Vector Group');
                    var gv = grp.property('ADBE Vectors Group');
                    var rc = gv.addProperty('ADBE Vector Shape - Rect');
                    rc.property('ADBE Vector Rect Size').setValue([rb.width + pad * 2, rb.height + pad * 1.2]);
                    rc.property('ADBE Vector Rect Position').setValue([rb.left + rb.width / 2, rb.top + rb.height / 2]);
                    rc.property('ADBE Vector Rect Roundness').setValue(st.box.r * st.sizePx);
                    var fl = gv.addProperty('ADBE Vector Graphic - Fill');
                    fl.property('ADBE Vector Fill Color').setValue(CK.hex(st.box.c));
                    fl.property('ADBE Vector Fill Opacity').setValue(st.box.a * 100);
                    B.moveAfter(L0);
                    B.parent = L0;
                    var bt = B.property('ADBE Transform Group');
                    bt.property('ADBE Anchor Point').setValue([0, 0]);
                    bt.property('ADBE Position').setValue([0, 0]);
                    bt.property('ADBE Opacity').expression = 'parent.transform.opacity';
                } catch (eB) {}
            }
            // 3D emoji above the caption
            if (c.emoji && c.emoji.file) {
                try {
                    var item = CK.aeEmojiItem(c.emoji.file);
                    if (item) {
                        var es = st.sizePx * 1.25, EL = comp.layers.add(item);
                        EL.name = base + 'emoji'; EL.comment = 'CaptionKit';
                        EL.startTime = 0;
                        EL.inPoint = Math.min(c.e - 0.05, c.s + (c.emoji.s || 0)); EL.outPoint = c.e;
                        var et = EL.property('ADBE Transform Group'), sc = es / Math.max(1, item.height) * 100;
                        et.property('ADBE Scale').setValue([sc, sc]);
                        et.property('ADBE Position').setValue([cx, top - es * 0.62]);
                        et.property('ADBE Scale').expression = 'var t=time-inPoint,p=Math.min(Math.max(t/0.35,0),1),e=1+2.70158*Math.pow(p-1,3)+1.70158*Math.pow(p-1,2);value*e';
                        et.property('ADBE Rotate Z').expression = 'var t=time-inPoint,p=Math.min(Math.max(t/0.35,0),1),e=1+2.70158*Math.pow(p-1,3)+1.70158*Math.pow(p-1,2);(1-e)*-20';
                        CK.addShadowFx(EL, '#000000', 0.35, es * 0.05, 180, es * 0.12);
                        if (st.exit && st.exit.o !== undefined) CK.aeLayerFx(EL, { exit: { o: st.exit.o, d: st.exit.d } }, st.sizePx, true);
                    }
                } catch (eE) {}
            }
            made++;
        }
        app.endUndoGroup();
        var miss = [];
        for (var m in missing) if (missing.hasOwnProperty(m)) miss.push(m);
        return CK.ok({ made: made, missingFonts: miss });
    } catch (e) {
        try { app.endUndoGroup(); } catch (e2) {}
        return CK.fail(e);
    }
}

CK.aeClear = function (comp) {
    var n = 0;
    for (var i = comp.numLayers; i >= 1; i--) {
        var L = comp.layer(i);
        if (L.comment === 'CaptionKit') { try { L.locked = false; L.remove(); n++; } catch (e) {} }
    }
    return n;
};

function ck_clear(arg) {
    try {
        if (CK.isAE()) {
            var comp = app.project.activeItem;
            if (!(comp && comp instanceof CompItem)) throw new Error('Open a composition first.');
            app.beginUndoGroup('CaptionKit: Clear Captions');
            var n = CK.aeClear(comp);
            app.endUndoGroup();
            return CK.ok({ removed: n });
        }
        return CK.ok({ removed: CK.ppClear() });
    } catch (e) { return CK.fail(e); }
}

/* =====================================================================
   PREMIERE PRO
   ===================================================================== */
CK.ppSources = function (mode) {
    var seq = app.project.activeSequence;
    if (!seq) throw new Error('Open a sequence first.');
    var segs = [], seen = {}, notes = [];
    function add(ti) {
        try {
            if (!ti || !ti.projectItem) return;
            var p = ti.projectItem.getMediaPath();
            if (!p) { notes.push(ti.name + ': nested/graphic clips are skipped'); return; }
            var sp = 1;
            try { sp = ti.getSpeed ? ti.getSpeed() : 1; } catch (e) {}
            try { if (ti.isSpeedReversed && ti.isSpeedReversed()) { notes.push(ti.name + ': reversed clips are skipped'); return; } } catch (e1) {}
            if (!sp || sp <= 0) sp = 1;
            var s = ti.start.seconds, en = ti.end.seconds, inP = ti.inPoint.seconds;
            var key = p + '|' + s.toFixed(2);
            if (seen[key]) return; seen[key] = 1;
            segs.push({ path: p, name: ti.name, tlStart: s, tlEnd: en, srcIn: inP, srcOut: inP + (en - s) * sp, speed: sp });
        } catch (e2) {}
    }
    if (mode === 'selected') {
        var sel = seq.getSelection();
        if (!sel || !sel.length) throw new Error('Select one or more clips in the timeline.');
        var aud = [], vid = [];
        for (var i = 0; i < sel.length; i++) (sel[i].mediaType === 'Audio' ? aud : vid).push(sel[i]);
        for (i = 0; i < aud.length; i++) add(aud[i]);
        for (i = 0; i < vid.length; i++) add(vid[i]);
    } else {
        for (var t = 0; t < seq.audioTracks.numTracks; t++) {
            var tr = seq.audioTracks[t];
            try { if (tr.isMuted()) continue; } catch (e) {}
            for (var c = 0; c < tr.clips.numItems; c++) add(tr.clips[c]);
        }
        if (!segs.length) for (var v = 0; v < seq.videoTracks.numTracks; v++) {
            var vt = seq.videoTracks[v];
            for (var c2 = 0; c2 < vt.clips.numItems; c2++) add(vt.clips[c2]);
        }
    }
    if (!segs.length) throw new Error('No clips with media found' + (notes.length ? ' (' + notes.join('; ') + ')' : '.'));
    var fps = 254016000000 / parseFloat(seq.timebase);
    return CK.ok({ segments: segs, notes: notes, target: { w: seq.frameSizeHorizontal, h: seq.frameSizeVertical, fps: fps } });
};

CK.ppBin = function (name) {
    var root = app.project.rootItem;
    for (var i = 0; i < root.children.numItems; i++) {
        var it = root.children[i];
        if (it.name === name && it.type === ProjectItemType.BIN) return it;
    }
    return root.createBin(name);
};

CK.norm = function (p) { return String(p).replace(/\\/g, '/').toLowerCase(); };

CK.ppNewTrack = function (seq) {
    var before = seq.videoTracks.numTracks;
    try {
        app.enableQE();
        var q = qe.project.getActiveSequence();
        q.addTracks(1, before, 0);
    } catch (e) {}
    if (seq.videoTracks.numTracks > before) return seq.videoTracks[seq.videoTracks.numTracks - 1];
    return null;
};

function ck_ppPlace(arg) {
    try {
        var a = CK.parse(arg), seq = app.project.activeSequence;
        if (!seq) throw new Error('Open a sequence first.');
        var bin = CK.ppBin('CaptionKit Captions');
        var sub = bin.createBin(a.runName);
        var track = CK.ppNewTrack(seq);
        if (!track) {
            // fall back to the top video track only if it is empty
            track = seq.videoTracks[seq.videoTracks.numTracks - 1];
            if (track.clips.numItems > 0) throw new Error('Could not add a new video track. Add an empty video track at the top of the sequence and try again.');
        }
        var placed = 0, used = {};
        for (var i = 0; i < a.renders.length; i++) {
            var r = a.renders[i];
            app.project.importFiles([r.first], true, sub, !r.still);
            var item = null, want = CK.norm(r.dir);
            for (var k = 0; k < sub.children.numItems; k++) {
                var ch = sub.children[k], mp = '';
                try { mp = CK.norm(ch.getMediaPath()); } catch (e) {}
                if (!used[k] && mp.indexOf(want) === 0) { item = ch; used[k] = 1; break; }
            }
            if (!item) continue;
            if (!r.still) {
                try { item.setOverrideFrameRate(a.fps); } catch (e1) {
                    try { var fi = item.getFootageInterpretation(); fi.frameRate = a.fps; item.setFootageInterpretation(fi); } catch (e2) {}
                }
            }
            var t = new Time(); t.seconds = r.start;
            track.overwriteClip(item, t);
            placed++;
        }
        try { track.name = 'CaptionKit'; } catch (e3) {}
        return CK.ok({ placed: placed });
    } catch (e) { return CK.fail(e); }
}

function ck_ppNative(arg) {
    try {
        var a = CK.parse(arg), seq = app.project.activeSequence;
        if (!seq) throw new Error('Open a sequence first.');
        if (!seq.createCaptionTrack) throw new Error('Native caption tracks need Premiere Pro 2021 (15.0) or newer. Use "Animated overlay" mode instead.');
        var bin = CK.ppBin('CaptionKit Captions');
        app.project.importFiles([a.srtPath], true, bin, false);
        var item = null, want = CK.norm(a.srtPath);
        for (var k = bin.children.numItems - 1; k >= 0; k--) {
            var mp = ''; try { mp = CK.norm(bin.children[k].getMediaPath()); } catch (e) {}
            if (mp === want) { item = bin.children[k]; break; }
        }
        if (!item) throw new Error('Could not import the caption file.');
        var fmt = Sequence.CAPTION_FORMAT_SUBTITLE;
        seq.createCaptionTrack(item, 0, fmt);
        return CK.ok({});
    } catch (e) { return CK.fail(e); }
}

CK.ppClear = function () {
    var seq = app.project.activeSequence;
    if (!seq) throw new Error('Open a sequence first.');
    var n = 0;
    for (var t = 0; t < seq.videoTracks.numTracks; t++) {
        var tr = seq.videoTracks[t];
        for (var c = tr.clips.numItems - 1; c >= 0; c--) {
            var ti = tr.clips[c], mp = '';
            try { mp = CK.norm(ti.projectItem.getMediaPath()); } catch (e) {}
            if (mp.indexOf('captionkit renders') > -1) { try { ti.remove(false, false); n++; } catch (e2) {} }
        }
    }
    return n;
};

/* =====================================================================
   TEXT TO SPEECH — import the generated voice and place it at the playhead
   ===================================================================== */
function ck_importAudio(arg) {
    try {
        var a = CK.parse(arg), f = new File(a.path);
        if (!f.exists) throw new Error('Audio file not found.');
        if (CK.isAE()) {
            var item = app.project.importFile(new ImportOptions(f));
            var comp = app.project.activeItem;
            if (comp && comp instanceof CompItem) {
                app.beginUndoGroup('CaptionKit: Add Voice');
                var L = comp.layers.add(item);
                L.startTime = comp.time;
                app.endUndoGroup();
                return CK.ok({ placed: true });
            }
            return CK.ok({ placed: false });
        }
        var bin = CK.ppBin('CaptionKit Audio');
        app.project.importFiles([f.fsName], true, bin, false);
        var it = null, want = CK.norm(f.fsName);
        for (var k = bin.children.numItems - 1; k >= 0; k--) {
            var mp = ''; try { mp = CK.norm(bin.children[k].getMediaPath()); } catch (e) {}
            if (mp === want) { it = bin.children[k]; break; }
        }
        var seq = app.project.activeSequence;
        if (!it || !seq) return CK.ok({ placed: false });
        var t = 0; try { t = seq.getPlayerPosition().seconds; } catch (e1) {}
        var dur = a.dur || 1, track = null;
        function free(tr) {
            for (var c = 0; c < tr.clips.numItems; c++) {
                var cl = tr.clips[c];
                if (cl.start.seconds < t + dur && cl.end.seconds > t) return false;
            }
            return true;
        }
        for (var i = 0; i < seq.audioTracks.numTracks && !track; i++) {
            var tr = seq.audioTracks[i], locked = false;
            try { locked = tr.isLocked && tr.isLocked(); } catch (e2) {}
            if (!locked && free(tr)) track = tr;
        }
        if (!track) {
            try { app.enableQE(); var q = qe.project.getActiveSequence(); q.addTracks(0, 0, 1, 1, seq.audioTracks.numTracks); } catch (e3) {}
            track = seq.audioTracks[seq.audioTracks.numTracks - 1];
            if (!free(track)) return CK.ok({ placed: false });
        }
        var tm = new Time(); tm.seconds = t;
        track.overwriteClip(it, tm);
        return CK.ok({ placed: true });
    } catch (e) { return CK.fail(e); }
}
